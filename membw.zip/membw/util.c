#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

#include "util.h"


//TODO内存对齐 并复制
void aligned_block_copy(int64_t * __restrict dst,
                        int64_t * __restrict src,
                        int size)
{
    char *s = (char*)src;
    char *d = (char*)dst;
    
    char *suffix = s + size;
    char *prefix = (char*)((uintptr_t)s & ~(sizeof(uint32_t) - 1));
    char *middle = (char*)((uintptr_t)suffix & ~(sizeof(uint32_t) - 1));
    
    if (prefix != s)
    {
        while (s < prefix + sizeof(uint32_t))
        {
            *d++ = *s++;
        }
    }
    
    uint32_t *s_int = (uint32_t*)s;
    uint32_t *d_int = (uint32_t*)d;
    
    while (s_int < (uint32_t*)(middle - 8 * sizeof(uint32_t)))
    {
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
    }
    
    while (s_int < (uint32_t*)(middle - 4 * sizeof(uint32_t)))
    {
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
    }
    
    while (s_int < (uint32_t*)(middle - 2 * sizeof(uint32_t)))
    {
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
    }
    
    while (s_int < (uint32_t*)middle)
    {
        *d_int++ = *s_int++;
    }
    
    char *s_char = (char*)s_int;
    char *d_char = (char*)d_int;
    
    while (s_char < suffix)
    {
        *d_char++ = *s_char++;
    }
}


//TODO  反向对齐 复制
void aligned_block_copy_backwards(int64_t * __restrict dst,
                                  int64_t * __restrict src,
                                  int size)
{
    char *s = (char*)src;
    char *d = (char*)dst;
    
    char *suffix = s + size;
    char *prefix = (char*)((uintptr_t)suffix & ~(sizeof(uint32_t) - 1));
    char *middle = (char*)((uintptr_t)s & ~(sizeof(uint32_t) - 1));
    
    if (prefix != suffix)
    {
        while (suffix > prefix)
        {
            *--d = *--suffix;
        }
    }
    
    uint32_t *s_int = (uint32_t*)suffix;
    uint32_t *d_int = (uint32_t*)d;
    
    while (s_int > (uint32_t*)(middle + 8 * sizeof(uint32_t)))
    {
        *--d_int = *--s_int;
        *--d_int = *--s_int;
        *--d_int = *--s_int;
        *--d_int = *--s_int;
        *--d_int = *--s_int;
        *--d_int = *--s_int;
        *--d_int = *--s_int;
        *--d_int = *--s_int;
    }
    
    while (s_int > (uint32_t*)(middle + 4 * sizeof(uint32_t)))
    {
        *--d_int = *--s_int;
        *--d_int = *--s_int;
        *--d_int = *--s_int;
        *--d_int = *--s_int;
    }
    
    while (s_int > (uint32_t*)(middle + 2 * sizeof(uint32_t)))
    {
        *--d_int = *--s_int;
        *--d_int = *--s_int;
    }
    
    while (s_int > (uint32_t*)middle)
    {
        *--d_int = *--s_int;
    }
    
    char *s_char = (char*)s_int;
    char *d_char = (char*)d_int;
    
    while (s_char > s)
    {
        *--d_char = *--s_char;
    }
}



//TODO   内存预取 prefetch  复制
void aligned_block_copy_pf(int64_t * __restrict dst,
                             int64_t * __restrict src,
                             int                  size)
{
    char *s = (char*)src;
    char *d = (char*)dst;
    
    char *suffix = s + size;
    char *prefix = (char*)((uintptr_t)s & ~(sizeof(uint32_t) - 1));
    char *middle = (char*)((uintptr_t)suffix & ~(sizeof(uint32_t) - 1));
    

    if (prefix != s)
    {
        while (s < prefix + sizeof(uint32_t))
        {
            *d++ = *s++;
        }
    }
    
    uint32_t *s_int = (uint32_t*)s;
    uint32_t *d_int = (uint32_t*)d;
    
    while (s_int < (uint32_t*)(middle - 8 * sizeof(uint32_t)))
    {
        __builtin_prefetch(s);
        __builtin_prefetch(d);
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
    }
    
    while (s_int < (uint32_t*)(middle - 4 * sizeof(uint32_t)))
    {
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
    }
    
    while (s_int < (uint32_t*)(middle - 2 * sizeof(uint32_t)))
    {
        *d_int++ = *s_int++;
        *d_int++ = *s_int++;
    }
    
    while (s_int < (uint32_t*)middle)
    {
        *d_int++ = *s_int++;
    }
    
    char *s_char = (char*)s_int;
    char *d_char = (char*)d_int;
    
    while (s_char < suffix)
    {
        *d_char++ = *s_char++;
    }
}

void aligned_block_fill(int64_t * __restrict dst,
                        int64_t * __restrict src,
                        int                  size)
{
    int64_t data = *src;
    while ((size -= 64) >= 0)
    {
        *dst++ = data;
        *dst++ = data;
        *dst++ = data;
        *dst++ = data;
        *dst++ = data;
        *dst++ = data;
        *dst++ = data;
        *dst++ = data;
    }
}

double gettime(void)
{
    struct timeval tv;
    gettimeofday (&tv, NULL);
    return (double)((int64_t)tv.tv_sec * 1000000 + tv.tv_usec) / 1000000.;
}


#define ALIGN_PADDING    0x100000
#define CACHE_LINE_SIZE  128

static char *align_up(char *ptr, int align)
{
    return (char *)(((uintptr_t)ptr + align - 1) & ~(uintptr_t)(align - 1));
}



void *alloc_four_aligned_buffers(void **buf1_, int size1,
                                    void **buf2_, int size2,
                                    void **buf3_, int size3,
                                    void **buf4_, int size4)
{
    printf("alloc_four_aligned_buffers\n");
    char **buf1 = (char **)buf1_, **buf2 = (char **)buf2_;
    char **buf3 = (char **)buf3_, **buf4 = (char **)buf4_;
    int antialias_pattern_mask = (ALIGN_PADDING - 1) & ~(CACHE_LINE_SIZE - 1);
    char *buf, *ptr;

    if (!buf1 || size1 < 0)
        size1 = 0;
    if (!buf2 || size2 < 0)
        size2 = 0;
    if (!buf3 || size3 < 0)
        size3 = 0;
    if (!buf4 || size4 < 0)
        size4 = 0;

    ptr = buf = 
        (char *)malloc(size1 + size2 + size3 + size4 + 9 * ALIGN_PADDING);

    ptr = align_up(ptr, ALIGN_PADDING);
    
    //TODO   下面5行不知道是否正确
    *buf1 = ptr;
    *buf2 = align_up(ptr + size1, ALIGN_PADDING);
    *buf3 = align_up(*buf2 + size2, ALIGN_PADDING);
    //*buf4 = align_up(*buf3 + size3, ALIGN_PADDING);
    //buf = align_up(*buf4 + size4, ALIGN_PADDING);

    
    return buf;
}
